1. $simpan = mysql_query("INSERT INTO table_Object VALUES('005','Komputer','30','4.000.000','P01')");



2. $update = mysql_query("UPDATE table_Object SET Nama_Object = 'Smart TV ' WHERE Kode_Object = '004'");



3. $tampil_data = mysql_query("SELECT * FROM table_Object WHERE Stock_Barang BETWEEN 20 AND 40");



4. $tampil_data_filter = mysql_query("SELECT * FROM table_Object WHERE Nama_Object LIKE 'Mo'");



5.<table>

<thead>

	<tr>

		<th>Kode_Object</th>

		<th>Nama_Object</th>

		<th>Jumlah_Harga </th>

	</tr>

</thead>

	<tbody>

		<?php

		$tampil_data = mysql_query("SELECT * FROM table_objek ");

		while ($r = mysql_fetch_array($tampil_data)) {

			$stok = $r['Stock_Barang'];

			$harga = $r['Harga_Satuan'];

			$hargajual = $stok * $harga;

			echo "<tr>

					<td>$r[Kode_Object]</td>

					<td>$r[Nama_Object]</td>

					<td >$hargajual</td>

					</tr>";

			$no++;

		}

		echo "

	</tbody>

</table>

?>



6 . <table>

<thead>

	<tr>

		<th>Kode_Object</th>

		<th>Nama_Object</th>

		<th>Nama_Penjual </th>

	</tr>

</thead>

	<tbody>

		<?php

		$tampil_data = mysql_query("SELECT * FROM table_objek 

		JOIN table_penjual ON table_objek.kode_penjual = table_penjual.kode_penjual");

		while ($r = mysql_fetch_array($tampil_data)) {

			echo "<tr>

					<td>$r[Kode_Object]</td>

					<td>$r[Nama_Object]</td>

					<td>$r[Nama_Penjual]</td>

					</tr>";

			$no++;

		}

		echo "

	</tbody>

</table>

?>



7.....  (LEFT JOIN)

<table>

<thead>

	<tr>

		<th>Kode_Object</th>

		<th>Nama_Object</th>

		<th>Nama_Penjual </th>

	</tr>

</thead>

	<tbody>

		<?php

		$tampil_data = mysql_query("SELECT * FROM table_objek 

		LEFT JOIN table_penjual ON table_objek.kode_penjual = table_penjual.kode_penjual");

		while ($r = mysql_fetch_array($tampil_data)) {

			echo "<tr>

					<td>$r[Kode_Object]</td>

					<td>$r[Nama_Object]</td>

					<td>$r[Nama_Penjual]</td>

					</tr>";

			$no++;

		}

		echo "

	</tbody>

</table>

?>



8.......

<table>



<thead>



	<tr>



		<th>Kode penjual</th>

		<th>Nama Penjual</th>

		<th>Jumlah_Harga </th>



	</tr>



</thead>



	<tbody>



		<?php



		$tampil_dataPENJUAL = mysql_query("SELECT * FROM table_penjual");



		while ($r = mysql_fetch_array($tampil_dataPENJUAL)) {

		

			$kode_penjual = $r['kode_penjual'];

		

			$tampil_dataBarang = mysql_query("SELECT SUM(stok_barang * hargasatuan) AS hsl FROM table_barang where kode_penjual = $kode_penjual");



			while ($r2 = mysql_fetch_array($tampil_dataBarang)) {

			

			$hsl = $r['hsl'];

			

			}



			echo "<tr>



					<td>$r[kode_penjual]</td>



					<td>$r[nm_penjual]</td>



					<td >$hsl</td>



					</tr>";



			$no++;



		}



		echo "



	</tbody>



</table>



?>



9......

$tampil_data = mysql_query("SELECT * FROM table_barang");



while ($r = mysql_fetch_array($tampil_data)) {

			

	$kode_barang = $r['kode_barang'];

	$analisa = $r['qty_barang'] * $r['hrg_barang'];

	

	if($analisa < 300.000.000){

	

		mysql_query("DELETE FROM table_barang WHERE kode_barang = '$kode_barang'");

		

	}else{

	

	}

			

}



10.....

<table>

<thead>

	<tr>

		<th>Nama_Object</th>

		<th>Nama_Penjual</th>

		<th>Object_Penjualan </th>



	</tr>

</thead>

	<tbody>

		<?php

		$tampil_data = mysql_query("SELECT * FROM table_objek 

		JOIN table_penjual ON table_objek.kode_penjual = table_penjual.kode_penjual");

		while ($r = mysql_fetch_array($tampil_data)) {

			echo "<tr>

					<td>$r[Nama_Object]</td>

					<td>$r[Nama_Penjual]</td>

					<td>$r[Nama_Object] - $r[Nama_Penjual]</td>

				</tr>";

		}

		echo "

	</tbody>

</table>



?>

